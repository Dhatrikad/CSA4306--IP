<?php
require 'database.php';
$q = trim($_GET['q'] ?? '');
$dept = trim($_GET['dept'] ?? '');
$books = $conn->query("SELECT * FROM books ORDER BY category, title");
$visibleCount = 0;
$departments = ['CSE', 'ECE', 'EEE', 'Engineering'];
?>
<!doctype html>
<html>
<head>
  <title>Book Catalog</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <a class="brand" href="index.php">College Library</a>
  <nav>
    <a href="index.php">Home</a>
    <a href="my_books.php">My Books</a>
    <a href="login.php">Login</a>
  </nav>
</header>
<main class="container">
  <h1>Book Catalog</h1>
  <form method="get" class="panel">
    <div class="grid" style="margin-top:0;">
      <div>
        <label for="q">Search</label>
        <input id="q" name="q" placeholder="Title, author or keyword" value="<?=e($q)?>">
      </div>
      <div>
        <label for="dept">Department</label>
        <select id="dept" name="dept">
          <option value="">All Departments</option>
          <?php foreach ($departments as $department): ?>
            <option value="<?=e($department)?>" <?=($dept === $department ? 'selected' : '')?>><?=e($department)?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <button>Search</button>
    <a class="btn secondary" href="books.php">Clear</a>
  </form>

  <div class="grid">
    <?php while ($b = $books->fetch_assoc()):
      $searchTerm = trim($q);
      $matchesSearch = $searchTerm === ''
        || stripos($b['title'], $searchTerm) !== false
        || stripos($b['author'], $searchTerm) !== false
        || stripos($b['category'], $searchTerm) !== false
        || stripos($b['description'], $searchTerm) !== false;
      $matchesDept = $dept === '' || $b['category'] === $dept;
      if (!$matchesSearch || !$matchesDept) continue;
      $visibleCount++;
      $status = $b['available'] > 0 ? 'Available' : 'Not available';
      $statusClass = $b['available'] > 0 ? 'notice' : 'error';
      ?>
      <article class="card">
        <span class="muted"><?=e($b['category'])?></span>
        <h3><?=e($b['title'])?></h3>
        <p><strong>Author:</strong> <?=e($b['author'])?></p>
        <p><strong>Available:</strong> <?=e($b['available'])?> / <?=e($b['quantity'])?> copies</p>
        <p class="<?=$statusClass?>" style="padding:8px 10px; margin:10px 0; display:inline-block; border-radius:8px;">
          <?=e($status)?></p>
        <p><?=e($b['description'])?></p>
        <a class="btn" href="book_details.php?id=<?=$b['id']?>">View details</a>
      </article>
    <?php endwhile; ?>
  </div>

  <?php if ($visibleCount === 0): ?>
    <div class="panel">
      <p>No books found for this department or search.</p>
    </div>
  <?php endif; ?>
</main>
</body>
</html>