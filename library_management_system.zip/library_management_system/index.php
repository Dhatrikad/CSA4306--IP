<?php require 'database.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Library Management System</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <div class="brand">📚 College Library</div>
  <nav>
    <a href="index.php">Home</a>
    <a href="books.php">Catalog</a>
    <a href="contact.php">Contact</a>
    <?php if(!empty($_SESSION['user_id'])): ?>
      <a href="my_books.php">My Books</a>
      <a href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Student Login</a>
      <a href="register.php">Register</a>
    <?php endif; ?>
    <a href="admin/login.php">Admin</a>
  </nav>
</header>
<div class="container">
  <section class="hero">
    <h1>Welcome to Library Management System</h1>
    <h2>College Library</h2>
    <p>Search, explore and request books easily across CSE, ECE, EEE and engineering departments.</p>
    <a class="btn" href="books.php">Browse Books</a>
    <a class="btn secondary" href="login.php">Student Login</a>
  </section>

  <div class="grid">
    <div class="card">
      <h3>📖 CSE Books</h3>
      <p>Core books for programming, OS, DBMS, data structures and networks.</p>
    </div>
    <div class="card">
      <h3>📡 ECE Books</h3>
      <p>Electronics and communication resources for circuits and systems.</p>
    </div>
    <div class="card">
      <h3>⚡ EEE Books</h3>
      <p>Electrical and power systems books for engineering students.</p>
    </div>
    <div class="card">
      <h3>🛠️ Engineering</h3>
      <p>General engineering and applied fundamentals for all departments.</p>
    </div>
  </div>
</div>
<footer>College Library Management System</footer>
</body>
</html>