<?php require 'database.php';
$id = (int)($_GET['id'] ?? 0);
$s = $conn->prepare("SELECT * FROM books WHERE id=?");
$s->bind_param("i", $id);
$s->execute();
$b = $s->get_result()->fetch_assoc();
?>
<!doctype html>
<html>
<head>
  <title>Book Details</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <a class="brand" href="index.php">College Library</a>
  <nav>
    <a href="books.php">Catalog</a>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <a href="my_books.php">My Books</a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
  <?php if (!$b): ?>
    <div class="panel">
      <h2>Book not found</h2>
      <a href="books.php">Return to catalog</a>
    </div>
  <?php else: ?>
    <div class="panel">
      <h1><?=e($b['title'])?></h1>
      <p><strong>Author:</strong> <?=e($b['author'])?></p>
      <p><strong>Department:</strong> <?=e($b['category'])?></p>
      <p><strong>ISBN:</strong> <?=e($b['isbn'])?></p>
      <p><strong>Availability:</strong> <?=e($b['available'])?> of <?=e($b['quantity'])?> copies available</p>
      <p><?=nl2br(e($b['description']))?></p>

      <?php if (!empty($_SESSION['user_id'])): ?>
        <?php if ($b['available'] > 0): ?>
          <a class="btn" href="borrow.php?id=<?=$b['id']?>&mode=instant">Instant issue</a>
          <a class="btn secondary" href="borrow.php?id=<?=$b['id']?>&mode=prebook">Pre-book</a>
        <?php else: ?>
          <a class="btn" href="borrow.php?id=<?=$b['id']?>&mode=prebook">Pre-book this book</a>
        <?php endif; ?>
      <?php else: ?>
        <a class="btn" href="login.php">Login to issue or pre-book</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</main>
</body>
</html>