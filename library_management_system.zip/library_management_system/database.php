<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$db = "library_db";

$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->query("CREATE DATABASE IF NOT EXISTS `$db`");
$conn->select_db($db);
$conn->set_charset("utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)");
$conn->query("CREATE TABLE IF NOT EXISTS books(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,author VARCHAR(150) NOT NULL,isbn VARCHAR(50),category VARCHAR(100) NOT NULL DEFAULT 'Engineering',quantity INT NOT NULL DEFAULT 1,available INT NOT NULL DEFAULT 1,description TEXT)");
$conn->query("CREATE TABLE IF NOT EXISTS issues(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,book_id INT NOT NULL,issue_date DATE NOT NULL,due_date DATE NOT NULL,return_date DATE NULL,status ENUM('Pending','Issued','Returned','Rejected') DEFAULT 'Pending',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE)");
$conn->query("CREATE TABLE IF NOT EXISTS messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

$check = $conn->query("SELECT id FROM admins LIMIT 1");
if ($check && $check->num_rows === 0) {
    $hash = password_hash("admin123", PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO admins(username,password) VALUES('admin',?)");
    $stmt->bind_param("s", $hash);
    $stmt->execute();
}

$bookCount = $conn->query("SELECT COUNT(*) AS total FROM books")->fetch_assoc()['total'] ?? 0;
if ((int)$bookCount === 0) {
    $sampleBooks = [
        ["Data Structures and Algorithms", "Robert Lafore", "978-813150", "CSE", 5, "Core CSE book for algorithmic thinking and practice."],
        ["Operating Systems", "Abraham Silberschatz", "978-812034", "CSE", 4, "Operating system concepts and process management basics."],
        ["Computer Networks", "Andrew Tanenbaum", "978-013212695", "CSE", 3, "Fundamentals of networking, TCP/IP and communication protocols."],
        ["Database Management Systems", "Raghu Ramakrishnan", "978-007246563", "CSE", 4, "Relational databases, SQL and indexing concepts."],
        ["Digital Electronics", "Morris Mano", "978-007060169", "ECE", 5, "Logic design, digital circuits and applications."],
        ["Signals and Systems", "Alan V. Oppenheim", "978-013814757", "ECE", 4, "Signal processing and system behavior fundamentals."],
        ["Microprocessors and Interfacing", "Douglas Hall", "978-007060169", "ECE", 3, "Microcontroller and processor interfacing concepts."],
        ["Communication Systems", "Simon Haykin", "978-812650", "ECE", 2, "Analog and digital communication techniques."],
        ["Electrical Machines", "P.S. Bimbhra", "978-812190", "EEE", 5, "DC and AC machine performance and design fundamentals."],
        ["Power Systems", "C. L. Wadhwa", "978-812032", "EEE", 3, "Transmission, distribution and power generation overview."],
        ["Control Systems", "Nagrath and Gopal", "978-812033", "EEE", 4, "Feedback systems and control theory applications."],
        ["Circuit Theory", "Sudhakar and Shyammohan", "978-812611", "EEE", 4, "Network analysis and circuit fundamentals."],
        ["Engineering Mathematics", "B.S. Grewal", "978-812190", "Engineering", 6, "Mathematics for engineering students and aptitude practice."],
        ["Engineering Drawing", "N.D. Bhatt", "978-938301", "Engineering", 5, "Drafting and diagrammatic engineering design basics."],
        ["Workshop Practice", "W.A.J. Chapman", "978-812190", "Engineering", 4, "Manual and practical engineering skills training."],
    ];

    foreach ($sampleBooks as $book) {
        [$title, $author, $isbn, $category, $quantity, $description] = $book;
        $available = $quantity;
        $stmt = $conn->prepare("INSERT INTO books(title,author,isbn,category,quantity,available,description) VALUES(?,?,?,?,?,?,?)");
        $stmt->bind_param("ssssiis", $title, $author, $isbn, $category, $quantity, $available, $description);
        $stmt->execute();
    }
}

function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function require_login() {
    if (empty($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
}

function require_admin() {
    if (empty($_SESSION['admin_id'])) {
        header("Location: login.php");
        exit;
    }
}
?>