<?php
require 'database.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$mode = $_GET['mode'] ?? 'instant';
$s = $conn->prepare("SELECT * FROM books WHERE id=?");
$s->bind_param("i", $id);
$s->execute();
$b = $s->get_result()->fetch_assoc();

$msg = '';
if (!$b) {
    $msg = "Book not found.";
} else {
    $activeCheck = $conn->prepare("SELECT id FROM issues WHERE user_id=? AND book_id=? AND status IN ('Pending','Issued')");
    $activeCheck->bind_param("ii", $_SESSION['user_id'], $id);
    $activeCheck->execute();
    if ($activeCheck->get_result()->num_rows) {
        $msg = "You already have an active request for this book.";
    } else {
        $issue = date('Y-m-d');
        $due = date('Y-m-d', strtotime('+14 days'));

        if ($mode === 'prebook' || $b['available'] < 1) {
            $stmt = $conn->prepare("INSERT INTO issues(user_id,book_id,issue_date,due_date,status) VALUES(?,?,?,?,'Pending')");
            $stmt->bind_param("iiss", $_SESSION['user_id'], $id, $issue, $due);
            $stmt->execute();
            $msg = "Your pre-book request has been submitted. The admin will confirm availability.";
        } else {
            $conn->begin_transaction();
            $update = $conn->prepare("UPDATE books SET available=available-1 WHERE id=? AND available>0");
            $update->bind_param("i", $id);
            $update->execute();

            if ($update->affected_rows) {
                $stmt = $conn->prepare("INSERT INTO issues(user_id,book_id,issue_date,due_date,status) VALUES(?,?,?,?,'Issued')");
                $stmt->bind_param("iiss", $_SESSION['user_id'], $id, $issue, $due);
                $stmt->execute();
                $conn->commit();
                $msg = "Book issued successfully. Please return it by " . $due . ".";
            } else {
                $conn->rollback();
                $msg = "This book is not available right now.";
            }
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <title>Book Request</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<main class="container">
  <div class="panel">
    <h2><?=e($msg)?></h2>
    <a href="my_books.php">My Books</a> | <a href="books.php">Catalog</a>
  </div>
</main>
</body>
</html>