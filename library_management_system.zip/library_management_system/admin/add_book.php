<?php
require '../database.php';
require_admin();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $t = trim($_POST['title'] ?? '');
    $a = trim($_POST['author'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $cat = trim($_POST['category'] ?? 'Engineering');
    $qty = max(0, (int)($_POST['quantity'] ?? 0));
    $desc = trim($_POST['description'] ?? '');

    if ($t && $a) {
        $s = $conn->prepare("INSERT INTO books(title,author,isbn,category,quantity,available,description) VALUES(?,?,?,?,?,?,?)");
        $s->bind_param("ssssiis", $t, $a, $isbn, $cat, $qty, $qty, $desc);
        if ($s->execute()) {
            header("Location: books.php");
            exit;
        } else {
            $msg = "Could not save book.";
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <title>Add Book</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<main class="form">
  <h2>Add Book</h2>
  <?php if ($msg) echo '<p class="error">' . e($msg) . '</p>'; ?>
  <form method="post">
    <label>Title</label>
    <input name="title" required>
    <label>Author</label>
    <input name="author" required>
    <label>ISBN</label>
    <input name="isbn">
    <label>Department</label>
    <select name="category">
      <option value="CSE">CSE</option>
      <option value="ECE">ECE</option>
      <option value="EEE">EEE</option>
      <option value="Engineering">Engineering</option>
    </select>
    <label>Quantity</label>
    <input type="number" min="0" name="quantity" value="1" required>
    <label>Description</label>
    <textarea name="description"></textarea>
    <button>Save Book</button>
  </form>
  <a href="books.php">Back</a>
</main>
</body>
</html>