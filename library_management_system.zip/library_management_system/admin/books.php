<?php
require '../database.php';
require_admin();
$rows = $conn->query("SELECT * FROM books ORDER BY category, title");
?>
<!doctype html>
<html>
<head>
  <title>Manage Books</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<header>
  <b>Admin</b>
  <nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="books.php">Books</a>
    <a href="issues.php">Requests</a>
    <a href="../logout.php">Logout</a>
  </nav>
</header>
<main class="container">
  <h1>Manage Books</h1>
  <a class="btn" href="add_book.php">Add New Book</a>
  <table>
    <tr>
      <th>ID</th>
      <th>Title</th>
      <th>Department</th>
      <th>Author</th>
      <th>Qty</th>
      <th>Available</th>
      <th>Actions</th>
    </tr>
    <?php while ($b = $rows->fetch_assoc()): ?>
      <tr>
        <td><?=$b['id']?></td>
        <td><?=e($b['title'])?></td>
        <td><?=e($b['category'])?></td>
        <td><?=e($b['author'])?></td>
        <td><?=$b['quantity']?></td>
        <td><?=$b['available']?></td>
        <td>
          <a href="edit_book.php?id=<?=$b['id']?>">Edit</a> |
          <a data-confirm="Delete this book?" href="delete_book.php?id=<?=$b['id']?>">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</main>
</body>
</html>