<?php
require '../database.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$s = $conn->prepare("SELECT * FROM books WHERE id=?");
$s->bind_param("i", $id);
$s->execute();
$b = $s->get_result()->fetch_assoc();
if (!$b) die("Book not found");

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $t = trim($_POST['title'] ?? '');
    $a = trim($_POST['author'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $cat = trim($_POST['category'] ?? 'Engineering');
    $qty = max(0, (int)($_POST['quantity'] ?? 0));
    $desc = trim($_POST['description'] ?? '');
    $issued = $b['quantity'] - $b['available'];

    if ($qty < $issued) {
        $msg = "Quantity cannot be less than currently issued copies.";
    } else {
        $avail = $qty - $issued;
        $s = $conn->prepare("UPDATE books SET title=?,author=?,isbn=?,category=?,quantity=?,available=?,description=? WHERE id=?");
        $s->bind_param("ssssiisi", $t, $a, $isbn, $cat, $qty, $avail, $desc, $id);
        if ($s->execute()) {
            header("Location: books.php");
            exit;
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <title>Edit Book</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<main class="form">
  <h2>Edit Book</h2>
  <?php if ($msg) echo '<p class="error">' . e($msg) . '</p>'; ?>
  <form method="post">
    <label>Title</label>
    <input name="title" value="<?=e($b['title'])?>" required>
    <label>Author</label>
    <input name="author" value="<?=e($b['author'])?>" required>
    <label>ISBN</label>
    <input name="isbn" value="<?=e($b['isbn'])?>">
    <label>Department</label>
    <select name="category">
      <?php foreach (['CSE', 'ECE', 'EEE', 'Engineering'] as $department): ?>
        <option value="<?=e($department)?>" <?=($b['category'] === $department ? 'selected' : '')?>><?=e($department)?></option>
      <?php endforeach; ?>
    </select>
    <label>Quantity</label>
    <input type="number" min="0" name="quantity" value="<?=e($b['quantity'])?>" required>
    <label>Description</label>
    <textarea name="description"><?=e($b['description'])?></textarea>
    <button>Update</button>
  </form>
  <a href="books.php">Back</a>
</main>
</body>
</html>