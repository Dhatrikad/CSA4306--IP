<?php
require 'database.php';
require_login();

$s = $conn->prepare("SELECT i.*, b.title, b.author, b.category FROM issues i JOIN books b ON b.id=i.book_id WHERE i.user_id=? ORDER BY i.id DESC");
$s->bind_param("i", $_SESSION['user_id']);
$s->execute();
$rows = $s->get_result();
?>
<!doctype html>
<html>
<head>
  <title>My Books</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <a class="brand" href="index.php">College Library</a>
  <nav>
    <a href="books.php">Catalog</a>
    <a href="logout.php">Logout</a>
  </nav>
</header>
<main class="container">
  <h1>My Book History</h1>
  <p>Welcome, <?=e($_SESSION['user_name'])?></p>
  <table>
    <tr>
      <th>Book</th>
      <th>Department</th>
      <th>Issue date</th>
      <th>Due date</th>
      <th>Status</th>
      <th>Returned on</th>
    </tr>
    <?php $found = false; while ($r = $rows->fetch_assoc()): $found = true; ?>
      <tr>
        <td><?=e($r['title'])?> — <?=e($r['author'])?></td>
        <td><?=e($r['category'])?></td>
        <td><?=e($r['issue_date'])?></td>
        <td><?=e($r['due_date'])?></td>
        <td><?=e($r['status'])?></td>
        <td><?=e($r['return_date'] ?? 'Not returned yet')?></td>
      </tr>
    <?php endwhile; ?>
  </table>
  <?php if (!$found): ?>
    <div class="panel">
      <p>You have not borrowed any books yet.</p>
    </div>
  <?php endif; ?>
  <a class="btn" href="books.php">Browse books</a>
</main>
</body>
</html>